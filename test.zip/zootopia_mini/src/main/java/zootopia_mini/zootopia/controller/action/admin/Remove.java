package zootopia_mini.zootopia.controller.action.admin;

public class Remove {

}
