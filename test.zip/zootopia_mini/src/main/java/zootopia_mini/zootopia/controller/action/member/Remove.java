package zootopia_mini.zootopia.controller.action.member;

public class Remove {

}
