package zootopia_mini.zootopia.controller.action.qna;

public class Remove {

}
