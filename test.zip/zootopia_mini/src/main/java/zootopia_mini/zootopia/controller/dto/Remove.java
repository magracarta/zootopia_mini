package zootopia_mini.zootopia.controller.dto;

public class Remove {

}
