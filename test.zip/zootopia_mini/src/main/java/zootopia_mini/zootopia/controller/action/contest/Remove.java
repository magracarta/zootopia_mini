package zootopia_mini.zootopia.controller.action.contest;

public class Remove {

}
