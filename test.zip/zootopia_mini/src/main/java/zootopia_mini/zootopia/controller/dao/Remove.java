package zootopia_mini.zootopia.controller.dao;

public class Remove {

}
